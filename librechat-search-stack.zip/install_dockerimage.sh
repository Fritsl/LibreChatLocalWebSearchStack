#!/bin/bash

# =============================================================================
# LibreChat Search Stack Installation Script
# Generated Configuration for SearXNG, Jina AI Reader, BGE Reranker
# =============================================================================

set -e

echo "🚀 Starting LibreChat Search Stack installation..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    echo "Visit: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    echo "Visit: https://docs.docker.com/compose/install/"
    exit 1
fi

echo "✅ Docker and Docker Compose are installed"

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p searxng
mkdir -p cache

# Set permissions
chmod 755 searxng
chmod 755 cache

# Pull Docker images
echo "📦 Pulling Docker images..."
if docker compose version &> /dev/null; then
    docker compose pull
else
    docker-compose pull
fi

# Start services
echo "🔄 Starting LibreChat Search Stack services..."
if docker compose version &> /dev/null; then
    docker compose up -d
else
    docker-compose up -d
fi

# Wait for services to be ready
echo "⏳ Waiting for services to start..."
sleep 30

# Check if services are running
echo "🔍 Checking service health..."
if docker compose version &> /dev/null; then
    SERVICE_STATUS=$(docker compose ps)
else
    SERVICE_STATUS=$(docker-compose ps)
fi

if echo "$SERVICE_STATUS" | grep -q "Up"; then
    echo "✅ LibreChat Search Stack is running successfully!"
    echo ""
    echo "🌐 Access your services at:"
   - SearXNG: http://localhost:8080
   - Jina AI Reader: http://localhost:3000
   - BGE Reranker: http://localhost:8787
    echo ""
    echo "📊 Service status:"
    echo "$SERVICE_STATUS"
    echo ""
    echo "📝 Useful commands:"
    echo "   View logs: docker compose logs -f (or docker-compose logs -f)"
    echo "   Stop services: docker compose down (or docker-compose down)"
    echo "   Restart services: docker compose restart (or docker-compose restart)"
    echo "   Update services: docker compose pull && docker compose up -d"
else
    echo "❌ Some services failed to start. Check logs:"
    if docker compose version &> /dev/null; then
        docker compose logs
    else
        docker-compose logs
    fi
    exit 1
fi

echo ""
echo "🎉 Installation complete! Your LibreChat Search Stack is ready!"
echo ""
echo "💡 Next steps:"
echo "   1. Add these environment variables to your LibreChat .env file:"
echo "      SEARXNG_INSTANCE_URL=http://localhost:8080"
echo "      FIRECRAWL_API_URL=http://localhost:3000"
echo "      RERANKER_BASE_URL=http://localhost:8787"
echo "   2. Restart LibreChat to apply the changes"
echo ""
