# LibreChat Search Stack

Self-hosted search infrastructure for LibreChat with SearXNG, Jina AI Reader, BGE Reranker.

## Quick Start

1. Clone or download this repository
2. Run the stack:

```bash
docker compose up -d
```

3. Verify services are running:

```bash
docker compose ps
```

## Services

### SearXNG (Port 8080)
- Privacy-respecting search engine
- Access: http://localhost:8080
- Memory: 1GB

### Jina AI Reader (Port 3000)
- Web scraper and content extractor
- API: http://localhost:3000
- Timeout: 30s
- Max Pages: 10
- Memory: 1GB

### BGE Reranker (Port 8787)
- AI-powered search result ranking
- API: http://localhost:8787
- Model: BAAI/bge-reranker-v2-m3
- Batch Size: 32
- Memory: 4GB

## LibreChat Integration

Add these environment variables to your LibreChat configuration:

```env
SEARXNG_INSTANCE_URL=http://localhost:8080
FIRECRAWL_API_URL=http://localhost:3000
RERANKER_BASE_URL=http://localhost:8787
```

## Management

Stop services:
```bash
docker compose down
```

View logs:
```bash
docker compose logs -f
```

Update services:
```bash
docker compose pull
docker compose up -d
```

## Support

For issues related to:
- LibreChat: https://github.com/danny-avila/LibreChat
- SearXNG: https://github.com/searxng/searxng
- Jina AI: https://github.com/jina-ai/reader